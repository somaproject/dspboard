def parse( parser, data ):
	class Node( tuple ):
		__slots__ = ['children']
		data = data
		def getChildren( self ):
			return map( self.__class__, self[3] )
		children = property(getChildren, None, None, """The children of this node""")
	# now parse the data
	success, nodes, next = parser.parse( data )
	return success, map(Node, nodes), next
