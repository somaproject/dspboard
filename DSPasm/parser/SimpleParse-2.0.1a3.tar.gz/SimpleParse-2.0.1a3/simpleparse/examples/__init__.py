'''Examples of use for the SimpleParse parser generator

Included are VRML97, EBNF and LISP parsers, as
well as a demonstration of using "pre-built"
parser nodes (particularly one based on the re
module).
'''