"""file := header, object
header := '#gen',[ \t]+,version,[ \t]+,applicationName,ts

applicationName := name
version := tuple

object := ('DEF', ts, Def,ts)?, classID, ts, dict,ts
Def := name
classID := dottedName
properties := propertyKey, ts, ':',ts,propertyValue

propertyKey := string
propertyValue := object / name / primitiveData
primitiveData := string / tuple / list / number

tuple := '(',ts,(propertyValue,ts,(',',ts)?)+,')'
list := '[',ts,(propertyValue,ts,(',',ts)?)+,']'
dict := '{', ts, properties, ts, '}'
"""