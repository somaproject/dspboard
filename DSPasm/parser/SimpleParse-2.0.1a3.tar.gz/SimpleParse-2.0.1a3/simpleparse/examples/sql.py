"""SQL Parser demo
http://www.contrib.andrew.cmu.edu/~shadow/sql/sql2bnf.aug92.txt
http://www.dsg.cs.tcd.ie/~anderssj/teaching/ISD/SQL%20Grammar%20and%20Syntax.pdf

"""